#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import tarfile
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "docs" / "downloads"
PACKAGE_NAME = "mac-photos-duplicate-finder"
DEFAULT_VERSION = "0.1.0"

INCLUDE_PATHS = [
    "README.md",
    "pyproject.toml",
    "scripts",
    "src",
    "tests",
]


@dataclass
class Distribution:
    filename: str
    format: str
    size_bytes: int
    sha256: str
    url: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build downloadable source distributions for the GitHub Pages site."
    )
    parser.add_argument(
        "--version",
        default=DEFAULT_VERSION,
        help=f"Distribution version label. Default: {DEFAULT_VERSION}.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Directory where downloadable archives and manifest will be written.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output_dir = args.output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    prefix = f"{PACKAGE_NAME}-{args.version}"
    zip_path = output_dir / f"{prefix}.zip"
    tar_path = output_dir / f"{prefix}.tar.gz"

    files = sorted(iter_distribution_files())
    write_zip(zip_path, prefix, files)
    write_tar_gz(tar_path, prefix, files)

    distributions = [
        describe_distribution(zip_path, "zip"),
        describe_distribution(tar_path, "tar.gz"),
    ]
    manifest = {
        "name": PACKAGE_NAME,
        "version": args.version,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "distributions": [asdict(distribution) for distribution in distributions],
    }
    (output_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    checksums = [
        f"{distribution.sha256}  {distribution.filename}"
        for distribution in distributions
    ]
    (output_dir / "SHA256SUMS.txt").write_text("\n".join(checksums) + "\n", encoding="utf-8")

    print(f"Wrote {len(distributions)} distributions to {output_dir}")
    for distribution in distributions:
        print(f"- {distribution.filename} | {distribution.size_bytes} bytes | {distribution.sha256}")
    return 0


def iter_distribution_files() -> list[Path]:
    files: list[Path] = []
    for include_path in INCLUDE_PATHS:
        path = PROJECT_ROOT / include_path
        if path.is_file():
            files.append(path)
            continue
        for child in path.rglob("*"):
            if child.is_file() and should_include(child):
                files.append(child)
    return files


def should_include(path: Path) -> bool:
    parts = set(path.relative_to(PROJECT_ROOT).parts)
    excluded = {
        ".git",
        ".codex",
        "__pycache__",
        ".pytest_cache",
        "reports",
        "docs",
        "dist",
        "build",
    }
    return not parts.intersection(excluded) and path.suffix != ".pyc"


def write_zip(path: Path, prefix: str, files: list[Path]) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for file_path in files:
            relative = file_path.relative_to(PROJECT_ROOT)
            archive.write(file_path, f"{prefix}/{relative}")


def write_tar_gz(path: Path, prefix: str, files: list[Path]) -> None:
    with tarfile.open(path, "w:gz") as archive:
        for file_path in files:
            relative = file_path.relative_to(PROJECT_ROOT)
            archive.add(file_path, arcname=f"{prefix}/{relative}")


def describe_distribution(path: Path, archive_format: str) -> Distribution:
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return Distribution(
        filename=path.name,
        format=archive_format,
        size_bytes=path.stat().st_size,
        sha256=digest,
        url=f"downloads/{path.name}",
    )


if __name__ == "__main__":
    raise SystemExit(main())
